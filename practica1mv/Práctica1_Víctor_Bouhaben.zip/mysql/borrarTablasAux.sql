-- Borrar las tablas auxiliares

DROP TABLE IF EXISTS Oferta;
DROP TABLE IF EXISTS Resultados;
DROP TABLE IF EXISTS Notas;
DROP TABLE IF EXISTS Movilidad;
DROP TABLE IF EXISTS Egresados;
DROP TABLE IF EXISTS Rendimiento;
